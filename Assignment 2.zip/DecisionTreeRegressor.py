import numpy as np
import os
import json
import operator
import warnings

warnings.filterwarnings("error")

class MyDecisionTreeRegressor():
    def __init__(self, max_depth=5, min_samples_split=1):
        '''
        Initialization
        :param max_depth: type: integer
        maximum depth of the regression tree. The maximum
        depth limits the number of nodes in the tree. Tune this parameter
        for best performance; the best value depends on the interaction
        of the input variables.
        :param min_samples_split: type: integer
        minimum number of samples required to split an internal node:

        root: type: dictionary, the root node of the regression tree.
        '''

        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.root = None


    def calc_y_Error(self, R, c):
        error = 0
        for i in range(len(R)):
            error += (R[i][-1] - c)**2
        
        return error

    def split(self, data, cols, depth):
        rows = len(data)
        split_tuple = (0,0)
        min_error = float("inf")
        split_value = float("inf")

        split_data_left = []
        left_pred = float("inf")
        split_data_right = []
        right_pred = float("inf")
        
        for j in range(cols):
            sorted_data = data[np.argsort(data[:,j])]    #Sort by column
            for s in range(rows):
                R1 = sorted_data[:s+1] #<=s
                R2 = sorted_data[s+1:] #>s

                try:
                    c1 = np.mean(R1[:,-1])
                except:
                    c1 = 0
                try:
                    c2 = np.mean(R2[:,-1])
                except:
                    c2 = 0

                error = self.calc_y_Error(R1, c1) + self.calc_y_Error(R2, c2)
                if min_error - error > 10**(-14):
                    min_error = error
                    split_tuple = (j,s)     #Warning: Column-Row format
                    split_value = sorted_data[s][j]
                    split_data_left = R1
                    split_data_right = R2
                    left_pred = c1
                    right_pred = c2
        
        tree_node = dict()
        tree_node["splitting_variable"] = split_tuple[0]
        tree_node["splitting_threshold"] = split_value
        
        if len(split_data_left) >= self.min_samples_split and depth < self.max_depth and len(split_data_left) > 1:
            tree_node["left"] = self.split(split_data_left, cols, depth+1)
        else:
            tree_node["left"] = left_pred
        
        if len(split_data_right) >= self.min_samples_split and depth < self.max_depth and len(split_data_right) > 1:
            tree_node["right"] = self.split(split_data_right, cols, depth+1)
        else:
            tree_node["right"] = right_pred
        
        return tree_node

    

    def fit(self, X, y):
        '''
        Inputs:
        X: Train feature data, type: numpy array, shape: (N, num_feature)
        Y: Train label data, type: numpy array, shape: (N,)

        You should update the self.root in this function.
        '''
        cols = len(X[0])
        rows = len(X)
        data = np.hstack((X,np.reshape(y, (rows, -1))))

        self.root = self.split(data, cols, 1)


    def predict(self, X):
        y_pred = [float("inf")]*len(X)

        '''
        :param X: Feature data, type: numpy array, shape: (N, num_feature)
        :return: y_pred: Predicted label, type: numpy array, shape: (N,)
        '''

        for i in range(len(X)):
            tree_node = self.root

            while(True):
                split_attrib = int(tree_node["splitting_variable"])
                if X[i][split_attrib] <= tree_node["splitting_threshold"]:
                    if isinstance(tree_node["left"], float):
                        y_pred[i] = tree_node["left"]
                        break
                    else:
                        tree_node = tree_node["left"]
                        continue
                elif X[i][split_attrib] > tree_node["splitting_threshold"]:
                    if isinstance(tree_node["right"], float):
                        y_pred[i] = tree_node["right"]
                        break
                    else:
                        tree_node = tree_node["right"]
                        continue

        return y_pred

    def get_model_string(self):
        model_dict = self.root
        return model_dict

    def save_model_to_json(self, file_name):
        model_dict = self.root
        with open(file_name, 'w') as fp:
            json.dump(model_dict, fp)


# For test
if __name__=='__main__':
    for i in range(3):  #3
        x_train = np.genfromtxt("Test_data" + os.sep + "x_" + str(i) +".csv", delimiter=",")
        y_train = np.genfromtxt("Test_data" + os.sep + "y_" + str(i) +".csv", delimiter=",")

        for j in range(2):  #2
            tree = MyDecisionTreeRegressor(max_depth=5, min_samples_split=j + 2)    #5,2
            tree.fit(x_train, y_train)

            model_string = tree.get_model_string()

            with open("Test_data" + os.sep + "decision_tree_" + str(i) + "_" + str(j) + ".json", 'r') as fp:
                test_model_string = json.load(fp)
            
            print(i,j,operator.eq(model_string, test_model_string))
            
            f = open(".\Results\dt_" + str(i) + "_" + str(j) + ".json", "w+")
            f.write(str(model_string).replace("'", "\""))
            f.close()

            y_pred = tree.predict(x_train)

            f2 = open(".\Results\dtpred_" + str(i) + "_" + str(j) + ".csv", "w+")
            f2.write(str(y_pred))
            f2.close()

            y_test_pred = np.genfromtxt("Test_data" + os.sep + "y_pred_decision_tree_"  + str(i) + "_" + str(j) + ".csv", delimiter=",")
            print(np.square(y_pred - y_test_pred).mean() <= 10**-10)
