import numpy as np
import warnings
warnings.filterwarnings("error")

data = np.array([[5,2,1], [4,6,7]])

print(data[1][-1])

a = 1.2345
b = {'a': 1, 'b':2.1}
print(isinstance(a, float))
print(isinstance(b, float))

'''
mean1 = np.mean(data[:3])
print(mean1)

try:
    mean2 = np.mean(data[3:])
except Exception as e:
    print("Hello I printed the first 10 chars of exception" + str(e))
    mean2 = 0
print(mean2)

'''